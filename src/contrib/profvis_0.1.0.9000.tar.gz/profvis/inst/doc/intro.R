## ----echo = FALSE--------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----eval=FALSE----------------------------------------------------------
#  devtools::install_github("rstudio/profvis")

## ----fig.show="hide"-----------------------------------------------------
library(profvis)

profvis({
  data(diamonds, package = "ggplot2")

  plot(price ~ carat, data = diamonds)
  m <- lm(price ~ carat, data = diamonds)
  abline(m, col = "red")
}, height = "250px")

## ------------------------------------------------------------------------
# Generate data
times <- 4e5
cols <- 150
data <- as.data.frame(x = matrix(rnorm(times * cols, mean = 5), ncol = cols))
data <- cbind(id = paste0("g", seq_len(times)), data)

profvis({
  data1 <- data   # Store in another variable for this run

  # Get column means
  means <- apply(data1[, names(data1) != "id"], 2, mean)

  # Subtract mean from each column
  for (i in seq_along(means)) {
    data1[, names(data1) != "id"][, i] <- data1[, names(data1) != "id"][, i] - means[i]
  }
}, height = "400px")

## ------------------------------------------------------------------------
profvis({
  data1 <- data
  # Four different ways of getting column means
  means <- apply(data1[, names(data1) != "id"], 2, mean)
  means <- colMeans(data1[, names(data1) != "id"])
  means <- lapply(data1[, names(data1) != "id"], mean)
  means <- vapply(data1[, names(data1) != "id"], mean, numeric(1))
}, height = "300px")

## ------------------------------------------------------------------------
profvis({
  data1 <- data
  means <- vapply(data1[, names(data1) != "id"], mean, numeric(1))

  for (i in seq_along(means)) {
    data1[, names(data1) != "id"][, i] <- data1[, names(data1) != "id"][, i] - means[i]
  }
}, height = "300px")

## ------------------------------------------------------------------------
profvis({
  data1 <- data

  # Given a column, normalize values and return them
  col_norm <- function(col) {
    col - mean(col)
  }

  # Apply the normalizer function over all columns except id
  data1[, names(data1) != "id"] <- lapply(data1[, names(data1) != "id"], col_norm)
}, height = "350px")

## ------------------------------------------------------------------------
profvis({
  data <- data.frame(value = runif(3e4))

  data$sum[1] <- data$value[1]
  for (i in seq(2, nrow(data))) {
    data$sum[i] <- data$sum[i-1] + data$value[i]
  }
}, height = "350px")

## ------------------------------------------------------------------------
profvis({
  csum <- function(x) {
    if (length(x) < 2) return(x)

    sum <- x[1]
    for (i in seq(2, length(x))) {
      sum[i] <- sum[i-1] + x[i]
    }
    sum
  }
  data$sum <- csum(data$value)
}, height = "320px")

## ------------------------------------------------------------------------
profvis({
  csum2 <- function(x) {
    if (length(x) < 2) return(x)

    sum <- numeric(length(x))  # Preallocate
    sum[1] <- x[1]
    for (i in seq(2, length(x))) {
      sum[i] <- sum[i-1] + x[i]
    }
    sum
  }
  data$sum <- csum2(data$value)
}, height = "350px")

## ----eval=FALSE----------------------------------------------------------
#  p <- profvis({
#    # Interesting code here
#  })
#  
#  # Open with RStudio viewer
#  print(p, viewer = TRUE)

## ------------------------------------------------------------------------
profvis({
  make_adder <- function(n) {
    function(x) {
      pause(0.25) # Wait for a moment so that this shows in the profiler
      x + n
    }
  }

  # Called with no intermediate variable, it shows as "<Anonymous>"
  make_adder(1)(10)

  # With the function saved in a variable, it shows as "adder2"
  adder2 <- make_adder(2)
  adder2(10)
}, height = "350px")

## ------------------------------------------------------------------------
lapply

## ----eval=FALSE----------------------------------------------------------
#  ## First, restart R ##
#  install.packages("ggplot2", type="source", INSTALL_opts="--with-keep.source")

## ----eval=FALSE----------------------------------------------------------
#  ## First, restart R ##
#  # Assuming sources are in a subdirectory ggplot2/
#  devtools::install("ggplot2", args="--with-keep.source")

## ----eval=FALSE----------------------------------------------------------
#  ## First, restart R ##
#  devtools::install_github("hadley/ggplot2", args="--with-keep.source")

## ----eval=FALSE----------------------------------------------------------
#  # Assuming sources are in a subdirectory ggplot2/
#  devtools::load_all("ggplot2")

## ----fig.show="hide"-----------------------------------------------------
library(ggplot2)
profvis({
  g <- ggplot(diamonds, aes(carat, price)) + geom_point(size = 1, alpha = 0.2)
  print(g)
})

## ----fig.show="hide"-----------------------------------------------------
profvis({
  try_seq_len <- function(n) {
    try({
      seq_len(n)
    }, silent = TRUE)
  }
  for (i in runif(1e4, min = -10, max = 100)) {
    try_seq_len(i)
  }
}, height = "300px")

## ------------------------------------------------------------------------
profvis({
  # Does not show in the flame graph
  Sys.sleep(0.25)

  # Does show in the flame graph
  pause(0.25)
}, height = "250px")

## ------------------------------------------------------------------------
profvis({
  times_5 <- function(x) {
    pause(0.5)
    x * 5
  }

  times_2 <- function(x) {
    pause(0.2)
    x * 2
  }

  times_10 <- function(x) {
    y <- times_5(x)
    times_2(y)
  }

  times_10_lazy <- function(x) {
    times_2(times_5(x))
  }

  times_10(10)
  times_10_lazy(10)
}, height = "350px")

## ------------------------------------------------------------------------
profvis({
  for (i in 1:3) {
    pause(0.1)
  }

  for (i in 1:3)
    pause(0.1)

}, height = "250px")

