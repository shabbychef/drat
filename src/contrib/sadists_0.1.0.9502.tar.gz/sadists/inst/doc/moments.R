## ----'preamble', include=FALSE, warning=FALSE, message=FALSE, cache=FALSE----
library(knitr)

# set the knitr options ... for everyone!
# if you unset this, then vignette build bonks. oh, joy.
#opts_knit$set(progress=TRUE)
opts_knit$set(eval.after='fig.cap')
# for a package vignette, you do want to echo.
# opts_chunk$set(echo=FALSE,warning=FALSE,message=FALSE)
opts_chunk$set(warning=FALSE,message=FALSE)
#opts_chunk$set(results="asis")
opts_chunk$set(cache=TRUE,cache.path="cache/moments")

#opts_chunk$set(fig.path="figure/",dev=c("pdf","cairo_ps"))
opts_chunk$set(fig.path="figure/moments",dev=c("pdf"))
#opts_chunk$set(fig.width=4.0,fig.height=6,dpi=200)
# see http://stackoverflow.com/q/23419782/164611
opts_chunk$set(fig.width=5.0,fig.height=3.0,out.width="5in",out.height="3in",dpi=200)

# doing this means that png files are made of figures;
# the savings is small, and it looks like shit:
#opts_chunk$set(fig.path="figure/",dev=c("png","pdf","cairo_ps"))
#opts_chunk$set(fig.width=4,fig.height=4)
# for figures? this is sweave-specific?
#opts_knit$set(eps=TRUE)

# this would be for figures:
#opts_chunk$set(out.width='.8\\textwidth')
# for text wrapping:
options(width=64,digits=2)
#opts_chunk$set(size="tiny")
opts_chunk$set(size="small")
opts_chunk$set(tidy=TRUE,tidy.opts=list(width.cutoff=36,keep.blank.line=TRUE))

compile.time <- Sys.time()

# from the environment

# only recompute if FORCE_RECOMPUTE=True w/out case match.
FORCE_RECOMPUTE <- 
	(toupper(Sys.getenv('FORCE_RECOMPUTE',unset='False')) == "TRUE")

# compiler flags!

# not used yet
LONG.FORM <- FALSE

mc.resolution <- ifelse(LONG.FORM,1000,200)
mc.resolution <- max(mc.resolution,100)

library(sadists)

gen_norm <- rnorm
lseq <- function(from,to,length.out) { 
	exp(seq(log(from),log(to),length.out = length.out))
}

## ----'naiveprodchisq',echo=TRUE,eval=TRUE,fig.cap="The Edgeworth expansion is inaccurate for the product of chi-squares variates."----
# moments of chi-square
chisq.moments <- function(df,order.max=3) {
	orders <- 1:order.max
	mu <- exp(orders * log(2) + lgamma(orders + (df/2)) - lgamma(df/2))
	return(mu)
}
# moments of product of chi-squares
prodchisq.moments <- function(dfs,order.max=3) {
	mu <- Reduce('*',sapply(dfs,chisq.moments,order.max=order.max,simplify=FALSE))
	return(mu)
}
rprodchisq <- function(n,dfs) {
	X <- Reduce('*',sapply(dfs,function(nu) { rchisq(n,df=nu) },simplify=FALSE))
	return(X)
}
require(PDQutils)
dprodchisq <- function(x,dfs,log=FALSE) {
	kappa <- PDQutils::moment2cumulant(prodchisq.moments(dfs,order.max=4))
	pdf <- dapx_edgeworth(x,kappa,support=c(0,Inf),log=log)
	return(pdf)
}

require(ggplot2)
test_dens <- function(dpqr,nobs,...) {
	rv <- sort(dpqr$r(nobs,...))
	data <- data.frame(draws=rv)
	text.size <- 6   # sigh

	# http://stackoverflow.com/a/5688125/164611
	p1 <- qplot(rv, geom = 'blank') +   
		geom_line(aes(y = ..density.., colour = 'Empirical'), stat = 'density') +  
		stat_function(fun = function(x) { dpqr$d(x,...) }, aes(colour = 'Theoretical')) +                       
		geom_histogram(aes(y = ..density..), alpha = 0.3) +                        
		scale_colour_manual(name = 'Density', values = c('red', 'blue')) +
		theme(text=element_text(size=text.size)) + 
		labs(title="Density (tests dfunc)")
	print(p1)
}

dfs <- c(40,30,50,20,10)
test_dens(list(r=rprodchisq,d=dprodchisq),nobs=2^14,dfs)


## ----'mc_check',echo=TRUE,eval=TRUE,results='asis'------------
require(PDQutils)
# cumulants of the log of the central chi-square
lc_cumuls <- function(df,order.max=3,orders=c(1:order.max)) {
	kappa <- psigamma(df/2,deriv=orders-1)
	kappa[1] <- kappa[1] + log(2)
	return(kappa)
}
# moments of the log of the central chi-square
lc_moments <- function(df,order.max=3,orders=c(1:order.max)) {
	kappa <- lc_cumuls(df,orders=orders)
	mu <- PDQutils::cumulant2moment(kappa)
	return(mu)
}
# moments of the log of the non-central chi-square
lnc_moments <- function(df,ncp=0,order.max=3,orders=c(1:order.max)) {
	stopifnot(ncp >=0)
	if (ncp > 0) {
		hancp <- ncp / 2.0
		# should be smarter about 0:100 here.
		allmu <- sapply(0:100,function(iv) {
										exp(-hancp + iv * log(hancp) - lfactorial(iv)) * lc_moments(df+2*iv,orders=orders)
			},simplify=FALSE)
		mu <- Reduce('+',allmu)
	} else {
		mu <- lc_moments(df=df,orders=orders)
	}
	return(mu)
}
set.seed(1231591)
df <- 50
ncp <- 1.5
nsim <- 1e6
x <- rchisq(nsim,df=df,ncp=ncp)
y <- log(x)

nord <- 6
empirical.mu <- sapply(1:nord,function(k) { mean(y^k) })
theoretical.mu <- lnc_moments(df=df,ncp=ncp,order.max=nord)

## ----'mc_check_table',echo=FALSE,eval=TRUE,results='asis'-----
summa.df <- data.frame(order=1:nord,empirical=empirical.mu,theoretical=theoretical.mu)
library(xtable)
print(xtable(summa.df,label='tab:mc_check',
	caption=paste0('Empirical and theoretical moments up to order ',nord,
	' are shown for $10^',log10(nsim),
	'$ draws from the log of a non-central chi-square distribution with ',
	df,' degrees of freedom and non-centrality parameter ',
	ncp,'.')),include.rownames=FALSE)

## ----'betterprodchisq',echo=TRUE,eval=TRUE,fig.cap="Applying the Edgeworth expansion to the sum of log chi-squares, then performing a change of variables, results in a more accurate density estimate."----
# cumulants of the log of the non-central chi-square
lnc_cumuls <- function(df,ncp=0,order.max=3,orders=c(1:order.max)) {
	mu <- lnc_moments(df,ncp,orders=orders)
	kappa <- PDQutils::moment2cumulant(mu)
	return(kappa)
}
# compute the cumulants of the sumlogchisq
# distribution. 
sumlogchisq_cumuls <- function(wts,df,ncp=0,order.max=3) {
	subkappa <- mapply(function(w,dd,nn) 
										 { (w ^ (1:order.max)) * lnc_cumuls(df=dd,ncp=nn,order.max=order.max) },
										 wts,df,ncp,SIMPLIFY=FALSE)
	kappa <- Reduce('+', subkappa)
	return(kappa)
}
dsumlogchisq <- function(x, wts, df, ncp=0, log = FALSE, order.max=6) {
	kappa <- sumlogchisq_cumuls(wts,df,ncp,order.max=order.max)
	retval <- PDQutils::dapx_edgeworth(x,kappa,log=log)
	return(retval)
}

# use change of variables:
dprodchisq2 <- function(x,dfs,log=FALSE) {
	dx <- dsumlogchisq(log(x),wts=1,df=dfs,ncp=0,log=log)
	if (log) {
		dx <- dx - log(x)
	} else {
		dx <- dx / x
	}
	return(dx)
}

dfs <- c(40,30,50,20,10)
test_dens(list(r=rprodchisq,d=dprodchisq2),nobs=2^14,dfs)

