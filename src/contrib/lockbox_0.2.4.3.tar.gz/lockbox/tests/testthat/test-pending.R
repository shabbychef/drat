context('pending')

test_that('it is pending', { expect_true(pending()) })
