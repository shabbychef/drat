#' Bundler-style Package Management for R.
#'
#' @name lockbox
#' @import yaml digest utils
#' @docType package
NULL
