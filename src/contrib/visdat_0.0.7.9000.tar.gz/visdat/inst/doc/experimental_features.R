## ----knitr-setup---------------------------------------------------------
knitr::opts_chunk$set(fig.width = 5, 
                      fig.height = 4)

## ----create-messy-vec----------------------------------------------------

messy_vector <- c(TRUE,
                  T,
                  "TRUE",
                  "T",
                  "01/01/01",
                  "01/01/2001",
                  NA,
                  NaN,
                  "NA",
                  "Na",
                  "na",
                  "10",
                  10,
                  "10.1",
                  10.1,
                  "abc",
                  "$%TG")

set.seed(1114)
messy_df <- data.frame(var1 = messy_vector,
                       var2 = sample(messy_vector),
                       var3 = sample(messy_vector))


## ----vis-guess-messy-df, fig.show='hold', out.width='50%'----------------
library(visdat)
vis_guess(messy_df)
vis_dat(messy_df)


## ----vis-compare-iris----------------------------------------------------
iris_diff <- iris
iris_diff[sample(1:150, 30),sample(1:4, 2)] <- NA

vis_compare(iris_diff, iris)


## ----vis-compare-error, eval = FALSE-------------------------------------
#  
#  iris_diff_2 <- iris
#  iris_diff_2$new_col <- iris$Sepal.Length + iris$Sepal.Width
#  
#  vis_compare(iris, iris_diff_2)
#  #> vis_compare is still in BETA! If you have suggestions or errors, post an issue at https://github.com/njtierney/visdat/issuesthe condition has length > 1 and only the first element will be usedError: `.x` (5) and `.y` (6) are different lengths

## ----vis-dat-ly----------------------------------------------------------
vis_dat_ly(airquality)

## ----vis-miss-ly---------------------------------------------------------

vis_miss_ly(airquality)


## ----vis-guess-ly--------------------------------------------------------
vis_guess_ly(typical_data)

## ----example-expectation, eval = FALSE-----------------------------------
#  
#  data %>%
#    expect(value == -1) %>%
#    vis_dat()
#  

## ----example-expectation-mech, eval = FALSE------------------------------
#  airquality %>%
#    mutate_if(is.numeric, .funs = function(x) x <= 10) %>%
#      dplyr::mutate(rows = seq_len(nrow(.))) %>%
#      tidyr::gather_(key_col = "variables",
#                     value_col = "valueType",
#                     gather_cols = names(.)[-length(.)]) %>%
#    ggplot2::ggplot(ggplot2::aes_string(x = "variables",
#                                        y = "rows")) +
#      ggplot2::geom_raster(ggplot2::aes_string(fill = "valueType")) +
#      ggplot2::theme_minimal() +
#      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45,
#                                       vjust = 1,
#                                       hjust = 1)) +
#      ggplot2::labs(x = "Variables in Dataset",
#           y = "Observations") +
#      # ggplot2::scale_x_discrete(limits = type_order_index) +
#      ggplot2::guides(fill = ggplot2::guide_legend(title = "Expectation"))

