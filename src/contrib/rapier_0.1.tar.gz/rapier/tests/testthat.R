library(testthat)
library(rapier)

test_check("rapier")
