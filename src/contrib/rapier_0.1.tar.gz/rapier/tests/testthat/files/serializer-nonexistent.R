#' @serializer flargdarg
#' @get /
function(){

}
