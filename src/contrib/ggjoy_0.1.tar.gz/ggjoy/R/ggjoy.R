#' ggjoy.
#'
#' @name ggjoy
#' @docType package
#' @import ggplot2
NULL
