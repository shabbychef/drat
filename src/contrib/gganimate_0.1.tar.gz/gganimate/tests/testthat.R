library(testthat)
library(gganimate)

test_check("gganimate")
