library(testthat)
library(realtR)

test_check("realtR")
