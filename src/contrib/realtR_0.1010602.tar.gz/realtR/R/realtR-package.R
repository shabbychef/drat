#' realtR
#'
#' Tools to make finding property
#' suck less
#'
#' @name realtoR
#' @docType package
#' @author Alex Bresler (abresler@@asbcllc.com)
#' @import dplyr purrr stringr stringr curl jsonlite rvest tidyr lubridate xml2 tibble readr stringi emo udpipe
#' @importFrom glue glue

NULL
