## ----'preamble', include=FALSE, warning=FALSE, message=FALSE, cache=FALSE----
library(knitr)

# set the knitr options ... for everyone!
# if you unset this, then vignette build bonks. oh, joy.
#opts_knit$set(progress=TRUE)
opts_knit$set(eval.after='fig.cap')
# for a package vignette, you do want to echo.
# opts_chunk$set(echo=FALSE,warning=FALSE,message=FALSE)
opts_chunk$set(warning=FALSE,message=FALSE)
#opts_chunk$set(results="asis")
opts_chunk$set(cache=TRUE,cache.path="cache/sadists")

#opts_chunk$set(fig.path="figure/",dev=c("pdf","cairo_ps"))
opts_chunk$set(fig.path="figure/sadists",dev=c("pdf"))
opts_chunk$set(fig.width=4.0,fig.height=6,dpi=200)

# doing this means that png files are made of figures;
# the savings is small, and it looks like shit:
#opts_chunk$set(fig.path="figure/",dev=c("png","pdf","cairo_ps"))
#opts_chunk$set(fig.width=4,fig.height=4)
# for figures? this is sweave-specific?
#opts_knit$set(eps=TRUE)

# this would be for figures:
#opts_chunk$set(out.width='.8\\textwidth')
# for text wrapping:
options(width=64,digits=2)
opts_chunk$set(size="small")
opts_chunk$set(tidy=TRUE,tidy.opts=list(width.cutoff=50,keep.blank.line=TRUE))

compile.time <- Sys.time()

# from the environment

# only recompute if FORCE_RECOMPUTE=True w/out case match.
FORCE_RECOMPUTE <- 
	(toupper(Sys.getenv('FORCE_RECOMPUTE',unset='False')) == "TRUE")

# compiler flags!

# not used yet
LONG.FORM <- FALSE

mc.resolution <- ifelse(LONG.FORM,1000,200)
mc.resolution <- max(mc.resolution,100)

library(sadists)

gen_norm <- rnorm
lseq <- function(from,to,length.out) { 
	exp(seq(log(from),log(to),length.out = length.out))
}

## ----'setup',echo=FALSE,eval=TRUE-----------------------------
require(ggplot2)
# from: http://www.cookbook-r.com/Graphs/Multiple_graphs_on_one_page_(ggplot2)/
# Multiple plot function
#
# ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
# - cols:   Number of columns in layout
# - layout: A matrix specifying the layout. If present, 'cols' is ignored.
#
# If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
# then plot 1 will go in the upper left, 2 will go in the upper right, and
# 3 will go all the way across the bottom.
#
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  require(grid)

  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }

 if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}
testf <- function(dpqr,nobs,...) {
	rv <- dpqr$r(nobs,...)
	data <- data.frame(draws=rv,pvals=dpqr$p(rv,...))

	# http://stackoverflow.com/a/5688125/164611
	p1 <- qplot(rv, geom = 'blank') +   
		geom_line(aes(y = ..density.., colour = 'Empirical'), stat = 'density') +  
		stat_function(fun = function(x) { dpqr$d(x,...) }, aes(colour = 'Theoretical')) +                       
		geom_histogram(aes(y = ..density..), alpha = 0.3) +                        
		scale_colour_manual(name = 'Density', values = c('red', 'blue')) +
		labs(title="Density (tests dfunc)")

	# Q-Q plot
	p2 <- ggplot(data, aes(sample = draws)) + stat_qq(dist=function(p) { dpqr$q(p,...) }) +
		labs(title="Q-Q plot (tests qfunc)")

	# empirical CDF of the p-values; should be uniform
	p3 <- ggplot(data, aes(sample = pvals)) + stat_qq(dist=qunif) + 
		labs(title="P-P plot (tests pfunc)")

	multiplot(p1,p2,p3,cols=1)
}

## ----'sumchisq',echo=TRUE,eval=TRUE,fig.cap="Confirming the DPQR functions of the sum of chi-square distribution."----
require(sadists)
wts <- c(1,-3,4)
df <- c(100,20,10)
ncp <- c(5,3,1)
testf(list(d=dsumchisq,p=psumchisq,q=qsumchisq,r=rsumchisq),nobs=2^14,wts,df,ncp)

## ----'sumchi',echo=TRUE,eval=TRUE,fig.cap="Confirming the DPQR functions of the sum of chis distribution."----
require(sadists)
wts <- c(-3,2,5,-4,1)
df <- c(30,50,100,20,10)
testf(list(d=dsumchi,p=psumchi,q=qsumchi,r=rsumchi),nobs=2^14,wts,df)

## ----'lambdap',echo=TRUE,eval=TRUE,fig.cap="Confirming the DPQR functions of the Lambda-prime distribution."----
require(sadists)
df <- 50
ts <- 1.5
# not yet:
#testf(list(d=dlambdap,p=plambdap,q=qlambdap,r=rlambdap),nobs=2^14,df,ts)
testf(list(d=dupsilon,p=pupsilon,q=qupsilon,r=rupsilon),nobs=2^14,df,ts)

## ----'upsilon',echo=TRUE,eval=TRUE,fig.cap="Confirming the DPQR functions of the Upsilon distribution."----
require(sadists)
df <- c(30,50,100,20,10)
ts <- c(-3,2,5,-4,1)
testf(list(d=dupsilon,p=pupsilon,q=qupsilon,r=rupsilon),nobs=2^14,df,ts)

## ----'nakagami',echo=TRUE,eval=TRUE,fig.cap="Confirming the DPQR functions of the Nakagami distribution."----
require(sadists)
m <- 120
Omega <- 4
testf(list(d=dnakagami,p=pnakagami,q=qnakagami,r=rnakagami),nobs=2^14,m,Omega)

## ----'dnt',echo=TRUE,eval=FALSE-------------------------------
#  require(sadists)
#  k <- 5
#  mu <- 1
#  theta <- 2
#  #testf(list(d=ddnt,p=pdnt,q=qdnt,r=rdnt),nobs=2^14,k,mu,theta)

